'use strict';

const http = require('http');
const os = require('os');

const PORT = process.env.PORT || 8080;
const APP_NAME = process.env.APP_NAME || 'unknown';
const VERSION = process.env.VERSION || '0.0.0';

function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(payload);
}

const server = http.createServer((req, res) => {
  // Read env vars fresh on every request rather than caching them at
  // startup, so the harness can flip APP_NAME/VERSION at runtime (e.g. via
  // a ConfigMap update + rollout) and GET / reflects the new values without
  // needing a code change.
  const appName = process.env.APP_NAME || 'unknown';
  const version = process.env.VERSION || '0.0.0';

  if (req.method === 'GET' && req.url === '/healthz') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('ok');
    return;
  }

  if (req.method === 'GET' && req.url === '/') {
    sendJson(res, 200, {
      app: appName,
      version: version,
      pod: os.hostname(),
    });
    return;
  }

  sendJson(res, 404, { error: 'not found' });
});

server.listen(PORT, () => {
  console.log(`${APP_NAME} v${VERSION} listening on :${PORT}`);
});

// Graceful shutdown so `kubectl rollout` / SIGTERM during a rolling update
// doesn't just get killed after the grace period.
process.on('SIGTERM', () => {
  server.close(() => process.exit(0));
});
