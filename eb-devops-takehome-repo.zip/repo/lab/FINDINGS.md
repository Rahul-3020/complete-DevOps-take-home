# Findings — Part 4 debug lab

> **Note on how this file was produced:** the fixes below for defects 1-4 were
> found by carefully reading `broken-chart/` against `cluster-state/` (a
> config/manifest review, not a live cluster — see README's "How I used AI"
> section for why). The `Cause` and `Fix` for those four are solid. The
> `Symptom` field for each still needs the **actual pasted output** from
> `./scenario.sh up` / `verify` / `kubectl` on a real cluster — that has not
> been fabricated, so paste it in as you run the lab. Not all six defects
> could be confirmed from the YAML alone (that's rather the point of the
> exercise — "trust the cluster, not your assumptions about the YAML"), so
> expect to find at least one more once the pods are actually running, most
> likely something tied to the closed-source app's runtime behaviour (e.g.
> filesystem writes under `readOnlyRootFilesystem: true`) rather than
> anything visible in the manifests.

Before you start investigating for real, begin recording:
`script -q part4-session.log` (or `asciinema rec part4-session.cast`), and
commit that file alongside this one.

---

## Defect 1 — gateway calling backend in the wrong namespace

**Symptom:** TODO — paste real output, e.g. `gateway`'s `/status` response
showing `"backend":"fail"` or similar, and/or `kubectl logs deploy/gateway`
showing connection/DNS errors to `backend.default.svc`.

**Cause:** `gateway.env.BACKEND_URL` was hardcoded to
`http://backend.default.svc:8080`, but the lab runs in the `debug-lab`
namespace (per `cluster-state/namespace.yaml` and how `scenario.sh` installs
the release). `backend.default.svc` resolves against the `default` namespace,
where no `backend` Service exists, so the lookup fails rather than connecting
to the real backend sitting in `debug-lab`.

**Fix:** Changed the URL to `http://backend.debug-lab.svc:8080` in
`values.yaml`. (A more robust fix would template this off
`.Release.Namespace` instead of hardcoding either namespace name — see
"what I'd do next" below.)

**How I found it:** Read `gateway`'s env block against the namespace the lab
actually installs into (`cluster-state/namespace.yaml` names it `debug-lab`;
`scenario.sh` also installs with `-n debug-lab`). The mismatch between the
hardcoded `default` in the URL and the real `debug-lab` namespace is visible
from the manifests alone — confirm live with
`kubectl -n debug-lab logs deploy/gateway` and the in-cluster probe in
`scenario.sh verify`.

---

## Defect 2 — metrics resource requests/limits exceed the namespace's LimitRange

**Symptom:** TODO — paste real output, e.g.
`kubectl -n debug-lab describe replicaset <metrics-rs>` showing a
FailedCreate event, something like:
`Error creating: pods "metrics-xxxx" is forbidden: maximum cpu usage per Container is 1, but limit is 4`.

**Cause:** `cluster-state/limits.yaml` sets a `LimitRange` with `max.cpu: "1"`
per container. `broken-chart/values.yaml` requested `cpu: "2"` / limited
`cpu: "4"` for `metrics`, above that ceiling. Kubernetes rejects pod creation
for any container that violates a namespace `LimitRange` max, so the
`metrics` Deployment could never get a Pod admitted.

**Fix:** Brought `metrics.resources` back in line with the other workloads
(`request: 50m / 64Mi`, `limit: 200m / 128Mi`), well under the LimitRange max.

**How I found it:** Compared every workload's `resources` block in
`values.yaml` against `cluster-state/limits.yaml`'s `max` — `metrics` was the
only one over the ceiling. Confirm live with
`kubectl -n debug-lab describe rs -l app=metrics` and look for a
`FailedCreate` event citing the LimitRange.

---

## Defect 3 — reporter's RoleBinding targets the wrong ServiceAccount

**Symptom:** TODO — paste real output, e.g.
`kubectl auth can-i list pods -n debug-lab --as=system:serviceaccount:debug-lab:reporter`
returning `no`, and/or the reporter's `/report` endpoint erroring or returning
no pod count.

**Cause:** `rbac.yaml`'s `RoleBinding` (`reporter-read`) had
`subjects: [{kind: ServiceAccount, name: default, ...}]`, binding the
`reporter-read` Role to the namespace's `default` ServiceAccount. But
`reporter.yaml`'s Deployment sets `serviceAccountName: reporter` — the
running pod uses a *different* ServiceAccount than the one the RoleBinding
grants permissions to, so the reporter pod has no RBAC access to list pods.

**Fix:** Changed the RoleBinding's subject to `name: reporter` so it matches
the ServiceAccount the Deployment actually uses.

**How I found it:** Cross-referenced `rbac.yaml`'s RoleBinding subject against
`reporter.yaml`'s `serviceAccountName` field — they named different SAs.
Confirm live with the `kubectl auth can-i ... --as=system:serviceaccount:debug-lab:reporter`
check that `scenario.sh verify` itself runs.

---

## Defect 4 — migrate Job has an invalid restartPolicy

**Symptom:** TODO — paste real output, e.g. the `helm upgrade --install`
error from `scenario.sh up`, something like:
`Job.batch "migrate" is invalid: spec.template.spec.restartPolicy: Unsupported value: "Always": supported values: "OnFailure", "Never"`.

**Cause:** `migrate-job.yaml` set `restartPolicy: Always` on the Job's pod
template. The Kubernetes API rejects this unconditionally for Jobs — a Job's
pod template may only use `OnFailure` or `Never`, since `Always` doesn't make
sense for a workload that's supposed to run to completion. This isn't a
scheduling problem or an image problem; the object fails API validation and
is never created at all, which is also why `scenario.sh up` prints its
"helm reported an error" note.

**Fix:** Changed `restartPolicy` to `OnFailure`, consistent with
`backoffLimit: 2` already being set for retry-on-failure semantics.

**How I found it:** Checked the Job's pod template against Kubernetes' known
constraints for `batch/v1 Job` — `restartPolicy: Always` is a hard validation
error, not a runtime symptom, so it's visible directly in
`helm upgrade --install`'s stderr the moment you try to install the chart.
Confirm live: this should be the very first error you see running
`./scenario.sh up`.

---

## Defect(s) 5 and 6 — not yet confirmed

I have not been able to run the lab against a live cluster, so I have not
confirmed the remaining defect(s) needed to reach six. My leading suspicion,
based on manifest review, is something to do with
`readOnlyRootFilesystem: true` (set uniformly across every workload) and
whether the (closed-source) app image needs a writable path — e.g. `/tmp` —
at runtime; if so it would show up as a CrashLoopBackOff on one or more
Deployments, and would need an `emptyDir` volume mounted at whatever path the
app needs, added via the chart. That's a guess to be tested, not a confirmed
finding — flagging it rather than "fixing" something unverified.

**What I'd do next:** run `./scenario.sh up`, then `kubectl -n debug-lab get
pods -w` and `kubectl -n debug-lab describe pod <name>` /
`kubectl -n debug-lab logs <name>` on anything not `1/1 Running`, work through
remaining `scenario.sh verify` failures one at a time, and update this file
with the real symptom output and root cause for whatever's found.
